import { apiCall, apiCallRaw, getToken, setToken, clearToken, setRefreshToken, clearRefreshToken, BASE } from './client'
import { saveCsv } from './saveCsv'
import { dayMonth, hhmm, minutesBetween, rosterStatus, cleanReason } from './attendance'

// ─── Helpers ──────────────────────────────────────────────────────────────────
function initials(name = '') {
  return name.split(' ').map(p => p[0]).join('').substring(0, 2).toUpperCase()
}

// Times come as Malaysia time without a zone, so they are read as written (see attendance.js)
function sessionAdapter(s) {
  const shownAt = s.opened_at ?? s.starts_at   // a missed class never opened
  const { day, month } = dayMonth(shownAt)
  const mins = s.opened_at && s.closed_at ? minutesBetween(s.opened_at, s.closed_at) : null
  return {
    id: s.id,
    class_id: s.class_id,
    class_code: s.class_code,
    class_name: s.class_name,
    day,
    month,
    time: hhmm(shownAt),
    duration: mins != null ? `${mins} min` : null,
    open: s.status === 'open',
    status: s.status,
    class_date: s.class_date ?? null,
    starts_at: s.starts_at ?? null,
    ends_at: s.ends_at ?? null,
    present: s.present ?? 0,
    late: s.late ?? 0,
    excused: s.excused ?? 0,
    absent: s.absent ?? 0,
    not_recorded: s.not_recorded ?? 0,
    unid: s.unid ?? 0,
    moodle_sync_status: s.moodle_sync_status ?? null,
    moodle_synced_at: s.moodle_synced_at ?? null,
    moodle_sync_next_at: s.moodle_sync_next_at ?? null,
    moodle_sync_error: s.moodle_sync_error ?? null,
    moodle_conflicts: s.moodle_conflicts ?? [],
  }
}

const AVATAR_COLORS = [
  { bg: '#EFF6FF', color: '#1D4ED8' },
  { bg: '#F0FDF4', color: '#15803D' },
  { bg: '#FFF7ED', color: '#C2410C' },
]

function studentAdapter(s, idx, sessionOpen) {
  const c = AVATAR_COLORS[idx % AVATAR_COLORS.length]
  return {
    id: s.matric_no,
    recordId: s.record_id,
    studentId: s.student_id,
    name: s.name,
    initials: initials(s.name),
    avatarBg: c.bg,
    avatarColor: c.color,
    status: rosterStatus(s.status, sessionOpen),
    arrivedAt: s.detected_at ? hhmm(s.detected_at) : null,
    overridden: s.overridden ?? false,
  }
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

// Turns a failed sign-in into a message the user can act on
function signInError(e, wrongCredentials, local) {
  if (e.status === 401) return new Error(wrongCredentials)
  // The server's check of the email field; never show its raw 422 body
  if (e.status === 422 && local) return new Error('Enter your email address.')
  if (e.status === 503) return new Error(e.message || 'SPeCTRUM is not reachable right now. Please try again later.')
  if (!e.status) return new Error("Can't reach the SmartClass server. Check your connection and try again.")
  return e
}

// Lecturers sign in with their SPeCTRUM (Moodle) account (FR-101). With `local`, the
// browser-only administrator sign-in uses a SmartClass email + password instead.
export const login = async (identifier, password, { local = false } = {}) => {
  let data
  try {
    data = local
      ? await apiCall('POST', '/auth/login', { email: identifier.trim(), password })
      : await apiCall('POST', '/auth/moodle-login', { username: identifier.trim(), password })
  } catch (e) {
    throw signInError(e, local ? 'Wrong email or password.' : 'Wrong SPeCTRUM username or password.', local)
  }
  const allowed = local ? ['lecturer', 'admin'] : ['lecturer']
  if (!allowed.includes(data.user.role)) {
    throw new Error('This app is for lecturers. Students use the SmartClass Student app.')
  }
  setToken(data.access_token)
  setRefreshToken(data.refresh_token)
  return {
    user: {
      name: data.user.name,
      email: data.user.email,
      role: data.user.role,
      initials: initials(data.user.name),
    },
  }
}

export const getLecturer = async () => {
  const u = await apiCall('GET', '/auth/me')
  return {
    name: u.name,
    email: u.email,
    initials: initials(u.name),
    staffId: u.lecturer?.staff_id ?? '',
    faculty: u.lecturer?.dept ?? '',
    role: u.role === 'admin' ? 'Administrator' : 'Lecturer',
    roleKey: u.role,
    id: u.id,
    isAdmin: u.role === 'admin',
  }
}

export const changePassword = async (current, next) => {
  return apiCall('PUT', '/auth/me/password', { current_password: current, new_password: next })
}

export const logout = async () => { clearToken(); clearRefreshToken() }

// ─── Classes ──────────────────────────────────────────────────────────────────

// Moodle full names often start with the code ("WIA2005 Algorithm Design"), and screens show both
function courseName(code, name) {
  const rest = name.startsWith(code) ? name.slice(code.length).replace(/^[\s:–—-]+/, '') : name
  return rest || name
}

export const getClasses = async () => {
  const list = await apiCall('GET', '/classes?full=1')
  return list.map(c => ({
    id: c.id,
    course_id: c.course_id,
    code: c.course_code,
    name: courseName(c.course_code, c.course_name),
    day_of_week: c.day_of_week ?? null,
    start_time: c.start_time ?? null,
    end_time: c.end_time ?? null,
    room: c.room ?? null,
  }))
}

export const getLecturerAllClasses = async () => {
  const list = await apiCall('GET', '/classes?full=1')
  return list.map(c => ({
    id: c.id,
    code: c.course_code,
    name: courseName(c.course_code, c.course_name),
    type: c.type,
    label: c.label ?? null,
    day_of_week: c.day_of_week,
    start_time: c.start_time,
    end_time: c.end_time,
    enrolled_count: c.enrolled_count ?? 0,
    room: c.room ?? null,
  }))
}

export const getClassStudents = async (classId) => {
  const list = await apiCall('GET', `/classes/${classId}/students`)
  return list.map(s => ({
    id: s.id,
    name: s.name,
    matric: s.matric_no,
    initials: initials(s.name),
    faceEnrolled: s.face_enrolled,
  }))
}

export const getCurrentClass = async () => {
  const list = await getClasses()
  return list[0] ?? null
}

// ─── Sessions ─────────────────────────────────────────────────────────────────

export const getSessions = async () => {
  const list = await apiCall('GET', '/lecturer/sessions')
  return list.map(sessionAdapter)
}

export const openSession = async (classId) => {
  const s = await apiCall('POST', '/lecturer/sessions', { occurrence_id: classId })
  return sessionAdapter(s)
}

// End the class early (FR-315)
export const closeSession = async (sessionId) => {
  const s = await apiCall('PUT', `/lecturer/sessions/${sessionId}/close`)
  return sessionAdapter(s)
}

export const extendSession = async (sessionId, minutes) =>
  sessionAdapter(await apiCall('POST', `/lecturer/sessions/${sessionId}/extend`, { minutes }))

// A class the job couldn't tell was held (FR-317)
export const confirmSession = async (sessionId, held) =>
  sessionAdapter(await apiCall('POST', `/lecturer/sessions/${sessionId}/confirm`, { held }))

// Moodle sync now instead of at the next try (FR-312)
export const retryMoodleSync = async (sessionId) =>
  sessionAdapter(await apiCall('POST', `/lecturer/sessions/${sessionId}/moodle-sync`))

// keep: 'smartclass' | 'moodle' (FR-320)
export const resolveMoodleConflict = async (sessionId, recordId, keep) =>
  sessionAdapter(await apiCall('POST', `/lecturer/sessions/${sessionId}/moodle-conflicts/${recordId}`, { keep }))

// ─── Interaction sessions (Module 5, S26) ───────────────────────────────

function mapInteraction(i) {
  return {
    id: i.id,
    occurrence_id: i.occurrence_id,
    class_code: i.class_code,
    class_name: i.class_name,
    status: i.status,
    opened_at: i.opened_at,
    closed_by: i.closed_by ?? null,
    closed_at: i.closed_at ?? null,
    current_poll: i.current_poll,
    live_question: i.live_question,
  }
}

// Every open interaction session across the lecturer's classes, newest first.
// Powers the Home card (UC-501): shows 'Live' without picking a class first.
export const getOpenInteractions = async () => {
  const list = await apiCall('GET', '/lecturer/interactions/open')
  return list.map(mapInteraction)
}

// Open interaction sessions for one class.
export const getInteractions = async (occurrenceId) => {
  const list = await apiCall('GET', `/lecturer/interactions?occurrence_id=${occurrenceId}`)
  return list.map(mapInteraction)
}

// One interaction session by id (used when navigating with interaction_id only).
export const getInteraction = async (interactionId) =>
  mapInteraction(await apiCall('GET', `/lecturer/interactions/${interactionId}`))

// Open an interaction session for a class (FR-501).
export const openInteraction = async (occurrenceId) =>
  apiCall('POST', '/lecturer/interactions', { occurrence_id: occurrenceId })

// Close an open interaction session (FR-501).
export const closeInteraction = async (interactionId) =>
  apiCall('POST', `/lecturer/interactions/${interactionId}/close`)

// Extend an open interaction session by `minutes` (mirrors the attendance extend).
export const extendInteraction = async (interactionId, minutes) =>
  apiCall('POST', `/lecturer/interactions/${interactionId}/extend`, { minutes })

// Create a live poll (FR-504).
export const createPoll = async (interactionId, { question, options }) =>
  apiCall('POST', `/lecturer/interactions/${interactionId}/polls`, { question, options })

// Close voting on a live poll — FR-504. The session itself stays open.
export const closePoll = async (interactionId, pollId) =>
  apiCall('POST', `/lecturer/interactions/${interactionId}/polls/${pollId}/close`)

// All polls for a session with live per-option counts.
export const getPolls = async (interactionId) =>
  apiCall('GET', `/lecturer/interactions/${interactionId}/polls`)

// All questions for a session (lecturer view; anonymous identity stripped).
export const getQuestions = async (interactionId) =>
  apiCall('GET', `/lecturer/interactions/${interactionId}/questions`)

// Post a live question to the class (FR-506).
export const postLiveQuestion = async (interactionId, question) =>
  apiCall('POST', `/lecturer/interactions/${interactionId}/live-question`, { question })

// The lecturer's current live question with responses (FR-506).
export const getLiveQuestion = async (interactionId) =>
  apiCall('GET', `/lecturer/interactions/${interactionId}/live-question`)

// Mark a student question as answered (FR-502).
export const markQuestionAnswered = async (interactionId, questionId) =>
  apiCall('POST', `/lecturer/interactions/${interactionId}/questions/${questionId}/answered`)

// Live per-reaction distinct-student counts (FR-507).
export const getReactions = async (interactionId) =>
  apiCall('GET', `/lecturer/interactions/${interactionId}/reactions`)

// Number of distinct students who signalled IDU (FR-508).
export const getIduCount = async (interactionId) =>
  apiCall('GET', `/lecturer/interactions/${interactionId}/idu`)

// ─── Class schedule (FR-301) ──────────────────────────────────────────

// All of day/start/end, or all null to clear the weekly slot. Moodle sync never overwrites it.
export const setWeeklySchedule = async (classId, { day, start, end, room }) => {
  const c = await apiCall('PUT', `/lecturer/classes/${classId}/schedule`, {
    day_of_week: day || null,
    start_time: start || null,
    end_time: end || null,
    room: room?.trim() || null,
  })
  return { day_of_week: c.day_of_week, start_time: c.start_time, end_time: c.end_time, room: c.room }
}

// ─── Attendance ───────────────────────────────────────────────────────────────

export const getStudents = async (sessionId, { sessionOpen = false } = {}) => {
  const list = await apiCall('GET', `/lecturer/sessions/${sessionId}/attendance`)
  return list.map((s, i) => studentAdapter(s, i, sessionOpen))
}

// "Says they're here" flags of one session, pending first (FR-318, FR-319)
export const getSessionFlags = (sessionId) => apiCall('GET', `/lecturer/flags?session_id=${sessionId}`)

export const confirmFlag = (flagId) => apiCall('POST', `/lecturer/flags/${flagId}/confirm`)

export const rejectFlag = (flagId, reason) =>
  apiCall('POST', `/lecturer/flags/${flagId}/reject`, { reason })

// The closest unmatched crop (FR-407); needs the token, so it goes through AuthImage
export const flagCropPath = (flagId) => `/lecturer/flags/${flagId}/crop`

// Any of the four statuses, with an optional reason that is audited (FR-305)
export const overrideAttendance = async (recordId, newStatus, sessionId, studentId, reason) => {
  const body = { status: newStatus, reason: cleanReason(reason) }
  if (recordId) {
    return apiCall('PUT', `/attendance/${recordId}/override`, body)
  }
  return apiCall('PUT', `/lecturer/sessions/${sessionId}/attendance/override`, { student_id: studentId, ...body })
}

export const exportSessionCsv = async (sessionId, filename) => {
  const res = await apiCallRaw('GET', `/lecturer/sessions/${sessionId}/export?format=csv`)
  const csvText = await res.text()
  return saveCsv(csvText, filename)
}

export const exportOccurrenceCsv = async (occId, filename, dateParams = {}) => {
  const qs = Object.keys(dateParams).length
    ? '?' + Object.entries(dateParams).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&')
    : ''
  const res = await apiCallRaw('GET', `/lecturer/occurrences/${occId}/attendance/export${qs}`)
  const csvText = await res.text()
  return saveCsv(csvText, filename)
}

// ─── Analytics ────────────────────────────────────────────────────────────────

export const getAnalytics = async (occurrenceId, dateParams = {}) => {
  const qs = Object.keys(dateParams).length
    ? '&' + Object.entries(dateParams).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&')
    : ''
  return apiCall('GET', `/lecturer/analytics?occurrence_id=${occurrenceId}${qs}`)
}

// ─── Face verification queue (FR-113) ────────────────────────────────────────

// Submissions waiting for review, oldest first; only students of the lecturer's courses
export const getPendingFaceSubmissions = async () => apiCall('GET', '/face-verification/pending')

export const approveFaceSubmission = async (id) => apiCall('POST', `/face-verification/${id}/approve`)

export const rejectFaceSubmission = async (id, reason) =>
  apiCall('POST', `/face-verification/${id}/reject`, { reason: reason.trim() })

// A review photo needs the token. An <img> can't send it, and Android's Image drops `headers`
// (new architecture), so the photo is fetched here: a blob URL on web (the caller revokes it),
// a data URI on phones.
export const fetchFaceImageUri = async (path, { web = false } = {}) => {
  const blob = await (await apiCallRaw('GET', path)).blob()
  if (web) return URL.createObjectURL(blob)
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = () => reject(new Error("Couldn't read the photo"))
    reader.readAsDataURL(blob)
  })
}

// ─── Admin area (browser only; the server answers 403 to anyone but an admin) ───

const query = (params) => {
  const parts = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
  return parts.length ? `?${parts.join('&')}` : ''
}

// Accounts (FR-103, FR-108): { items, total, page, limit }
export const adminListUsers = async ({ q, role, status, page = 1, limit = 50 } = {}) =>
  apiCall('GET', `/admin/users${query({ q: q?.trim(), role, status, page, limit })}`)

export const adminDeactivateUser = async (id) => apiCall('DELETE', `/admin/users/${id}`)

export const adminReactivateUser = async (id) => apiCall('POST', `/admin/users/${id}/reactivate`)

export const adminCreateAdmin = async ({ name, email, password }) =>
  apiCall('POST', '/admin/users', { name: name.trim(), email: email.trim(), password, role: 'admin' })

// Deletes the student's face data and closes a pending submission (FR-117)
export const adminResetFaceData = async (userId) => apiCall('DELETE', `/admin/students/${userId}/face-data`)

export const adminAuditLogs = async ({ page = 1, limit = 50 } = {}) =>
  apiCall('GET', `/admin/audit-logs${query({ page, limit })}`)

// Moodle sync (FR-104): the last full sync (null before the first) and "Sync now"
export const adminLastSync = async () => apiCall('GET', '/admin/moodle/sync')

export const adminSyncNow = async () => apiCall('POST', '/admin/moodle/sync')

// Camera devices (FR-408). The key comes back only from register/regenerate and is never stored.
export const adminListDevices = async () => apiCall('GET', '/admin/devices')
export const adminRegisterDevice = async ({ name, room }) =>
  apiCall('POST', '/admin/devices', { name: name.trim(), room: room.trim() })
export const adminRegenerateDeviceKey = async (id) => apiCall('POST', `/admin/devices/${id}/regenerate-key`)

// ─── AI Learning Assistant (Module 8) ────────────────────────────────────────

// Courses the lecturer teaches, with how many materials are indexed (FR-815)
export const getAssistantCourses = async () => {
  const list = await apiCall('GET', '/lecturer/assistant/courses')
  return list.map(c => ({
    id: c.course_id,
    code: c.code,
    name: courseName(c.code, c.name),
    indexedMaterials: c.indexed_materials ?? 0,
  }))
}

// Each material's processing status (FR-804)
export const getMaterials = async (courseId) => {
  const list = await apiCall('GET', `/kb/courses/${courseId}/materials`)
  return list.map(m => ({
    id: m.id,
    title: m.title,
    fileName: m.file_name,
    section: m.section_name ?? null,
    status: m.status,
    errorText: m.error_text ?? null,
    units: m.unit_count ?? null,
    chunks: m.chunk_count ?? 0,
  }))
}

// "Sync now": pull changes from Moodle immediately (FR-803)
export const syncMaterials = async (courseId) => apiCall('POST', `/kb/courses/${courseId}/sync`)

// Anonymised question trends (FR-813, NFR-09)
export const getQuestionTrends = async (courseId) => {
  const t = await apiCall('GET', `/lecturer/assistant/trends/${courseId}`)
  return {
    mostAsked: t.most_asked_topics ?? [],
    mostCited: t.most_cited_materials ?? [],
    uncovered: t.topics_materials_dont_cover ?? [],
  }
}

// "Ask my materials" (FR-815): the lecturer's own chat sessions for a course
export const getLecturerSessions = async (courseId) =>
  apiCall('GET', `/lecturer/assistant/sessions?course_id=${courseId}`)

export const createLecturerSession = async (courseId) =>
  apiCall('POST', '/lecturer/assistant/sessions', { course_id: courseId })

export const getLecturerMessages = async (sessionId) =>
  apiCall('GET', `/lecturer/assistant/sessions/${sessionId}/messages`)

export const sendLecturerMessage = async (sessionId, content) =>
  apiCall('POST', `/lecturer/assistant/sessions/${sessionId}/messages`, { content })

// "Before next class" summary (FR-816)
export const getBeforeClass = async (courseId) =>
  apiCall('GET', `/lecturer/assistant/before-class/${courseId}`)

// ─── Quiz (Module 6, S35) ──────────────────────────────────────────────────

// Draft (and approved) questions for a course the lecturer teaches (FR-604).
// Can filter by quizId or pass unlinkedOnly=true for brand new builder sessions.
export const getQuizDrafts = async (courseId, { quizId, unlinkedOnly } = {}) => {
  let url = `/lecturer/quizzes/drafts?course_id=${courseId}`
  if (quizId != null) url += `&quiz_id=${quizId}`
  else if (unlinkedOnly) url += '&unlinked_only=true'
  return apiCall('GET', url)
}

// Draft `count` questions of `type`/`level` from the selected materials (FR-601/602/603).
export const generateQuiz = async (courseId, { material_ids, type, level, count }) =>
  apiCall('POST', `/lecturer/courses/${courseId}/quizzes/generate`, {
    material_ids, type, level, count,
  })

// Edit a draft question (FR-604).
export const editQuizQuestion = async (questionId, data) =>
  apiCall('PUT', `/lecturer/quizzes/questions/${questionId}`, data)

// Approve a draft question (draft → approved) (FR-604).
export const approveQuizQuestion = async (questionId) =>
  apiCall('POST', `/lecturer/quizzes/questions/${questionId}/approve`)

// Soft-delete a draft question (draft → deleted) (FR-604).
export const deleteQuizQuestion = async (questionId) =>
  apiCall('DELETE', `/lecturer/quizzes/questions/${questionId}`)

// Publish approved questions as a quiz (FR-605) — optionally to several courses at once
// (one quiz per course; the question copies appear in each class).
export const publishQuiz = async ({ question_ids, time_limit_minutes, opens_at, closes_at, title, attempts_allowed, review_visible, course_ids }) =>
  apiCall('POST', '/lecturer/quizzes', {
    question_ids, time_limit_minutes, opens_at, closes_at,
    title, attempts_allowed, review_visible, course_ids: course_ids ?? [],
  })

// ─── Quiz quiz-sets / draft flow (S35) ──────────────────────────────────────

// Get details of one quiz (including total enrolled count).
export const getQuiz = async (quizId) =>
  apiCall('GET', `/lecturer/quizzes/${quizId}`)

// All quizzes (draft / published / closed) of a course the lecturer teaches.
export const getCourseQuizzes = async (courseId) =>
  apiCall('GET', `/lecturer/courses/${courseId}/quizzes`)

// Get all questions of a quiz for lecturer view.
export const getQuizQuestionsForLecturer = async (quizId) =>
  apiCall('GET', `/lecturer/quizzes/${quizId}/questions`)

// Save a draft quiz set from the given question ids (review → publish later).
export const saveQuizDraft = async ({ question_ids, title, time_limit_minutes, opens_at, closes_at, attempts_allowed, review_visible }) =>
  apiCall('POST', '/lecturer/quizzes/draft', {
    question_ids, title, time_limit_minutes, opens_at, closes_at,
    attempts_allowed, review_visible,
  })

// Edit a draft quiz's details (title, window, time limit, attempts, review).
export const updateQuizDraft = async (quizId, data) =>
  apiCall('PUT', `/lecturer/quizzes/${quizId}`, data)

// Publish a draft quiz — to its own course plus clones to the listed course ids.
export const publishQuizDraft = async (quizId, courseIds = []) =>
  apiCall('POST', `/lecturer/quizzes/${quizId}/publish`, { course_ids: courseIds })

// Add a question manually (review/edit/add flow).
export const createQuizQuestion = async (data) =>
  apiCall('POST', '/lecturer/quizzes/questions', data)

// One-sentence quiz builder (LLM): "create 5 mcq, 2 short answer, duration 15min,
// valid two days from now" → parses the spec, drafts questions, saves a draft quiz.
export const quickAddQuiz = async (courseId, { prompt, material_ids, level }) =>
  apiCall('POST', `/lecturer/courses/${courseId}/quizzes/quick-add`, {
    prompt, material_ids: material_ids ?? [], level,
  })

// Attempts for a quiz the lecturer teaches (NFR-04) (FR-612 data).
export const getQuizAttempts = async (quizId) =>
  apiCall('GET', `/lecturer/quizzes/${quizId}/attempts`)

// All answers (MCQ + Short Answer) for an attempt (lecturer review).
export const getAllAttemptAnswers = async (attemptId) =>
  apiCall('GET', `/lecturer/quizzes/attempts/${attemptId}/all-answers`)

// Unscored short answers on an attempt (FR-609).
export const getUnscoredAnswers = async (attemptId) =>
  apiCall('GET', `/lecturer/quizzes/attempts/${attemptId}/answers`)

// Score a short answer (FR-609).
export const scoreShortAnswer = async (attemptId, answerId, score) =>
  apiCall('POST', `/lecturer/quizzes/attempts/${attemptId}/answers/${answerId}/score`, { score })

// AI-suggested score for a short answer (FR-610).
export const suggestScore = async (attemptId, answerId) =>
  apiCall('POST', `/lecturer/quizzes/attempts/${attemptId}/answers/${answerId}/suggest-score`)

// Per-question results for an attempt (visible only after grading complete).
export const getAttemptResult = async (attemptId) =>
  apiCall('GET', `/student/quizzes/attempts/${attemptId}/result`)
